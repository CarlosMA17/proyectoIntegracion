package com.app.mappers.scrapyard;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.app.entity.ScrapYard;
import com.app.entity.ScrapYardParts;
import com.app.dtos.bookdto.ScrapYardPartsResponseDto;
import com.app.dtos.bookdto.ScrapYardRequestDto;

@Mapper(componentModel = "spring")
public interface ScrapYardMapper {

	// Dto -> Entity
	@Mapping(target = "scrapYardId", ignore = true)
	/*@Mapping(target = "price", ignore = true)
	@Mapping(target = "scrapYardName", ignore = true)
	@Mapping(target = "stock", ignore = true)
	@Mapping(target = "wearLevel", ignore = true)*/
	ScrapYard toBook(ScrapYardRequestDto scrapYardRequestDto);
	
	// Entity -> Dto
	
	@Mapping(target = "partName", ignore = true)
	@Mapping(target = "price", ignore = true)
	@Mapping(target = "scrapYardName", ignore = true)
	@Mapping(target = "stock", ignore = true)
	@Mapping(target = "wearLevel", ignore = true)
	ScrapYardPartsResponseDto toResponse(ScrapYardParts scrapYard);
}
